
VOICE TOOL - QUICK DEPLOY (Cyclic.sh free)
-----------------------------------------

1) Create a new GitHub repo and push the backend files (server.js, package.json).
2) Go to https://www.cyclic.sh and sign up with GitHub.
3) Click 'New App' and connect your backend repo.
4) Set start command (if prompted): npm start
5) Add environment variable in Cyclic dashboard: OPENAI_API_KEY = your_openai_key
6) After deployment note the public URL (e.g., https://your-app.oncyclic.app).
7) Use that URL as API Base in the frontend (clean.html).
